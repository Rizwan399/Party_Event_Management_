package com.example.backend.entity;

public enum Role {
    USER,
    ADMIN
}
